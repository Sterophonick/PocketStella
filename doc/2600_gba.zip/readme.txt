This package contains the complete sourcecode to an atari2600 emulator for the gameboy advance.

Please see the CREDITS file for more information

If you would like to continue this project, please contact me gbaemu@email.com

PLEASE NOTE THIS IS NOT A SUPPORT ADDRESS!

Thankyou for taking the time to read this.